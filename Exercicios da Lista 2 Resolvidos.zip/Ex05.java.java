import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    
	    int i = 0;
	    int numero  = 0;
		
		for(i = 100; i >= 1; i--){
		    
		    if(i % 2 == 0){
		         System.out.println(i);
		         
		    }
		    
		}
		
	}
}
