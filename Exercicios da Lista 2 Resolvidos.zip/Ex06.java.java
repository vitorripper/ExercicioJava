import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner;
	    
	    int i = 0;
	    int maior = 0
	    int menor 

		
		do{
		    
		    System.out.print("Escreva seu nome: ");
		    String nome = sc.next();
		
		    System.out.print("Qual sua idade: ");
		    int idade = sc.nextInt();
		
		    System.out.print("Qual seu sexo: ");
		    String sexo = sc.next();
		    
		    i = i + 5;
		
		    if(idade > maior){
		    maior = idade
		    
		    
		    }
		    
		    
		  
		}
		while(idade > maior){
		    maior = idade
		}
		
		
		
		    
	}
		
		
		
	    
}

